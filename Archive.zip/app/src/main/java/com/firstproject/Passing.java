package com.firstproject;
import java.time.Instant;

public class Passing {
    public Instant time;
    public String node;
    public long val;
}
